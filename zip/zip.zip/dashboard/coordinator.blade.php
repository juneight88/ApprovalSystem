<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard - Head of Office/Subject Coordinator</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4">
        <h2 class="text-center">Coordinator Dashboard</h2>
        <a href="/request-form" class="btn btn-primary w-100 mb-3">File a Request</a>
        <a href="/request-history" class="btn btn-secondary w-100 mb-3">Request History</a>
        <a href="/manage-requests" class="btn btn-info w-100">Manage Requests</a>
    </div>
</body>
</html>
