<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard - Personnel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4">
        <h2 class="text-center">Personnel Dashboard</h2>
        <a href="/request-form" class="btn btn-primary w-100 mb-3">File a Request</a>
        <a href="/request-history" class="btn btn-secondary w-100">Request History</a>
    </div>
</body>
</html>
