<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Requests</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script> <!-- FontAwesome Icons -->
</head>
<body class="container mt-5">
    <h2 class="text-center mb-4">Manage Requests</h2>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>Department</th>
                <th>Test Category</th>
                <th>Date Request</th>
                <th>Type of Document</th>
                <th>Subject</th>
                <th>Modality</th>
                <th>Mode</th>
                <th>Exam Date</th>
                <th>Time Allotment</th>
                <th>No. of Pages</th>
                <th>No. of Copies</th>
                <th>Status</th>
                <th>Actions</th>
                <th>Comment</th> <!-- Added a column for Comment -->
            </tr>
        </thead>
        <tbody>
            @foreach ($requests as $request)
                <tr>
                    <td>{{ $request->department }}</td>
                    <td>{{ $request->test_category }}</td>
                    <td>{{ $request->date_request }}</td>
                    <td>{{ $request->type_of_document }}</td>
                    <td>{{ $request->subject }}</td>
                    <td>{{ $request->modality_of_learning }}</td>
                    <td>{{ $request->mode }}</td>
                    <td>{{ $request->date_exam_required }}</td>
                    <td>{{ $request->exam_time_allotment }}</td>
                    <td>{{ $request->number_of_pages }}</td>
                    <td>{{ $request->number_of_copies }}</td>
                    <td>{{ $request->status }}</td>
                    <td>
                        <a href="/approve-request/{{ $request->id }}" class="btn btn-success btn-sm">Approve</a>
                        <a href="/reject-request/{{ $request->id }}" class="btn btn-danger btn-sm">Reject</a>
                    </td>
                    <td>
                        <!-- View Comment Button -->
                        <button class="btn btn-info btn-sm" onclick="toggleComment({{ $request->id }})">
                            <i class="fas fa-sticky-note"></i> View Comment
                        </button>

                        <!-- Hidden Comment Section -->
                        <div id="comment-{{ $request->id }}" style="display: none;" class="mt-2">
                            <strong>Comment:</strong> {{ $request->comments ?? 'No comments yet' }}

                            <!-- Comment Form -->
                            <form action="/add-comment/{{ $request->id }}" method="POST" class="mt-2">
                                @csrf
                                <input type="text" name="comment" class="form-control" placeholder="Add a comment" required>
                                <button type="submit" class="btn btn-warning mt-2 w-100">Submit</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <a href="/dashboard" class="btn btn-primary mt-3">Back to Dashboard</a>

    <script>
        function toggleComment(id) {
            let commentDiv = document.getElementById('comment-' + id);
            commentDiv.style.display = commentDiv.style.display === "none" ? "block" : "none";
        }
    </script>

</body>
</html>
