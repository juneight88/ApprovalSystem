<!DOCTYPE html>
<html lang="en">
<head>
    <title>Request History</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2 class="text-center mb-4">Request History</h2>

    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>Department</th>
                <th>Test Category</th>
                <th>Date Request</th>
                <th>Type of Document</th>
                <th>Subject</th>
                <th>Modality</th>
                <th>Mode</th>
                <th>Exam Date</th>
                <th>Time Allotment</th>
                <th>No. of Pages</th>
                <th>No. of Copies</th>
                <th>File</th>
                <th>Status</th> <!-- Added Status Column -->
            </tr>
        </thead>
        <tbody>
            @foreach ($requests as $request)
                <tr>
                    <td>{{ $request->department }}</td>
                    <td>{{ $request->test_category }}</td>
                    <td>{{ $request->date_request }}</td>
                    <td>{{ $request->type_of_document }}</td>
                    <td>{{ $request->subject }}</td>
                    <td>{{ $request->modality_of_learning }}</td>
                    <td>{{ $request->mode }}</td>
                    <td>{{ $request->date_exam_required }}</td>
                    <td>{{ $request->exam_time_allotment }}</td>
                    <td>{{ $request->number_of_pages }}</td>
                    <td>{{ $request->number_of_copies }}</td>
                    <td>
                        @if ($request->file)
                            <a href="{{ asset('storage/' . $request->file) }}" target="_blank" class="btn btn-info btn-sm">
                                View File
                            </a>
                        @else
                            No file
                        @endif
                    </td>
                    <td>
                        @if ($request->status == 'pending')
                            <span class="badge bg-warning text-dark">Pending</span>
                        @elseif ($request->status == 'approved')
                            <span class="badge bg-success">Approved</span>
                        @elseif ($request->status == 'rejected')
                            <span class="badge bg-danger">Rejected</span>
                        @else
                            <span class="badge bg-secondary">Unknown</span>
                        @endif
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <a href="/dashboard" class="btn btn-primary mt-3">Back to Dashboard</a>
</body>
</html>
