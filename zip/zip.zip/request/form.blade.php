<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Form</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: url('your-background-image.png') no-repeat center center;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .form-container {
            background: rgba(255, 255, 255, 0.9);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            max-width: 700px;
            width: 100%;
        }

        .form-label {
            font-weight: bold;
        }

        .form-control, .form-select {
            border-radius: 8px;
        }

        .btn-custom {
            border-radius: 8px;
            padding: 10px 20px;
            width: 120px;
            font-size: 16px;
        }

        .btn-cancel {
            background-color: #ccc;
            color: black;
        }

        .btn-submit {
            background-color: black;
            color: white;
        }

        .file-upload {
            display: flex;
            align-items: center;
            gap: 10px;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h3 class="text-center mb-4">Request Form</h3>

    <form action="/submit-request" method="POST" enctype="multipart/form-data">
        @csrf

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="department" class="form-label">Department:</label>
                <input type="text" class="form-control" name="department" required>
            </div>
            <div class="col-md-6">
                <label for="date_exam_required" class="form-label">* Date of Exam/Required:</label>
                <input type="date" class="form-control" name="date_exam_required" required>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="test_category" class="form-label">Test Category:</label>
                <input type="text" class="form-control" name="test_category" required>
            </div>
            <div class="col-md-6">
                <label for="exam_time_allotment" class="form-label">Exam Time Allotment:</label>
                <input type="text" class="form-control" name="exam_time_allotment" placeholder="e.g. 1 hour" required>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="date_request" class="form-label">Date Request:</label>
                <input type="date" class="form-control" name="date_request" required>
            </div>
            <div class="col-md-6">
                <label for="number_of_pages" class="form-label">* No. of Pages:</label>
                <input type="number" class="form-control" name="number_of_pages" required>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="type_of_document" class="form-label">* Type of Document:</label>
                <select class="form-select" name="type_of_document" required>
                    <option value="Test Questionnaire">Test Questionnaire</option>
                    <option value="Document">Document</option>
                </select>
            </div>
            <div class="col-md-6">
                <label for="number_of_copies" class="form-label">* No. of Copies:</label>
                <input type="number" class="form-control" name="number_of_copies" required>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="subject" class="form-label">Subject:</label>
                <select class="form-select" name="subject" required>
                    <option value="1">IT Networking 1</option>
                    <option value="245">245</option>
                </select>
            </div>
            <div class="col-md-6">
                <label for="modality_of_learning" class="form-label">Modality of Learning:</label>
                <select class="form-select" name="modality_of_learning" required>
                    <option value="online">Online</option>
                    <option value="face to face">Face-to-face</option>
                </select>
            </div>
        </div>

        <div class="mb-3">
            <label for="mode" class="form-label">Mode:</label>
            <select class="form-select" name="mode" required>
                <option value="Print both sides">Print on Both Sides</option>
                <option value="Print one side only">Print on One Side Only</option>
            </select>
        </div>

        <div class="mb-3 file-upload">
            <label for="file" class="form-label">Attach a File:</label>
            <input type="file" class="form-control" name="file" accept="application/pdf">
        </div>

        <div class="d-flex justify-content-between">
            <button type="reset" class="btn btn-cancel btn-custom">Cancel</button>
            <button type="submit" class="btn btn-submit btn-custom">Submit</button>
        </div>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
