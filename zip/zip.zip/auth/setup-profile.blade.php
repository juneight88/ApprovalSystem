<!DOCTYPE html>
<html lang="en">
<head>
    <title>Profile Setup</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4">
        <h2 class="text-center">Personal Information Setup</h2>

        <form action="/setup-profile" method="POST">
            @csrf
            <div class="mb-3">
                <label>First Name</label>
                <input type="text" name="first_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Last Name</label>
                <input type="text" name="last_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Role</label>
                <select name="role" class="form-control" required>
                    <option value="Personnel">Personnel</option>
                    <option value="Non-teaching personnel">Non-teaching personnel</option>
                    <option value="Admin">Admin</option>
                    <option value="Head of Office">Head of Office</option>
                    <option value="Subject Coordinator">Subject Coordinator</option>
                </select>
            </div>
            <div class="mb-3">
                <label>Department</label>
                <select name="department" class="form-control" required>
                    <option value="1">Department 1</option>
                    <option value="2">Department 2</option>
                    <option value="3">Department 3</option>
                    <option value="4">Department 4</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary w-100">Save Profile</button>
        </form>
    </div>
</body>
</html>
