<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\User;

class UserController extends Controller
{
    // Show the profile setup form
    public function setupProfile()
    {
        $user = Session::get('user');
        return view('auth.setup-profile', compact('user'));
    }

    // Save the profile setup and redirect to the dashboard
    public function saveProfile(Request $request)
{
    $user = Session::get('user');

    // Validate
    $request->validate([
        'first_name' => 'required|string',
        'last_name' => 'required|string',
        'role' => 'required|string',
        'department' => 'required|string',
        'handled_subjects' => 'required|array',
    ]);

    // Save
    $user->first_name = $request->first_name;
    $user->last_name = $request->last_name;
    $user->role = $request->role;
    $user->department = $request->department;
    $user->handled_subjects = json_encode($request->handled_subjects);
    $user->save();

    return redirect('/dashboard');
}


    // Show the dashboard based on user role
    public function dashboard()
    {
        $user = Session::get('user');

        // Based on user role, show the correct dashboard page
        if ($user->role == 'Personnel' || $user->role == 'Non-teaching personnel') {
            return view('dashboard.personnel');  // Dashboard for Personnel and Non-teaching personnel
        }

        if ($user->role == 'Head of Office' || $user->role == 'Subject Coordinator') {
            return view('dashboard.coordinator');  // Dashboard for Head of Office and Subject Coordinator
        }

        if ($user->role == 'Admin') {
            return view('dashboard.admin');  // Dashboard for Admin
        }

        if ($user->role == 'Super Admin') {
            return view('dashboard.super_admin');  // Dashboard for Super Admin
        }
    }
}
