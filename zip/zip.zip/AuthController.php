<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\User;

class AuthController extends Controller
{
    // Show the login form
    public function showLoginForm()
    {
        return view('auth.login');
    }

    // Handle the login logic
    public function login(Request $request)
    {
        // Validate login input
        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);

        // Find the user by username and password
        $user = User::where('username', $request->username)
                    ->where('password', $request->password)
                    ->first();

        if ($user) {
            // Store user in session
            Session::put('user', $user);

            // Check if the profile is set up, otherwise redirect to setup
            if (!$user->first_name || !$user->last_name || !$user->role || !$user->department) {
                return redirect('/setup-profile');  // Redirect to profile setup if not completed
            }

            // Redirect to the respective dashboard based on the user's role
            return redirect('/dashboard');  // Redirect to dashboard
        }

        return back()->with('error', 'Invalid credentials');
    }

    // Handle logout
    public function logout()
    {
        Session::forget('user');
        return redirect('/login');
    }
}

