<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request as HttpRequest;
use App\Models\Request;
use App\Models\User; // For fetching the Head of Office/Dean
use Illuminate\Support\Facades\Session;

class RequestController extends Controller
{
    // Show the request form
    public function showRequestForm()
    {
        return view('request.form');
    }

    // Handle the request form submission
    public function submitRequest(HttpRequest $request)
    {
        $user = Session::get('user');

        // Validate
        $validated = $request->validate([
            'department' => 'required|string',
            'test_category' => 'required|string',
            'type_of_document' => 'required|string',
            'subject' => 'required|string',
            'modality_of_learning' => 'required|string',
            'mode' => 'required|string',
            'date_exam_required' => 'required|date',
            'exam_time_allotment' => 'required|integer',
            'number_of_pages' => 'required|integer',
            'number_of_copies' => 'required|integer',
            'file' => 'nullable|mimes:pdf|max:2048',
        ]);

        // Find the Subject Coordinator
        $subject = Subject::where('name', $validated['subject'])->first();
        $coordinator_id = $subject ? $subject->coordinator_id : null;

        // Store file if uploaded
        $filePath = null;
        if ($request->hasFile('file')) {
            $filePath = $request->file('file')->store('requests', 'public');
        }

        // Create request
        Request::create([
            'department' => $validated['department'],
            'test_category' => $validated['test_category'],
            'date_request' => now(),
            'type_of_document' => $validated['type_of_document'],
            'subject' => $validated['subject'],
            'modality_of_learning' => $validated['modality_of_learning'],
            'mode' => $validated['mode'],
            'date_exam_required' => $validated['date_exam_required'],
            'exam_time_allotment' => $validated['exam_time_allotment'],
            'number_of_pages' => $validated['number_of_pages'],
            'number_of_copies' => $validated['number_of_copies'],
            'file' => $filePath,
            'user_id' => $user->id,
            'coordinator_id' => $coordinator_id,
            'status' => 'pending',
        ]);

        return redirect('/dashboard')->with('success', 'Request submitted successfully!');
    }

    public function requestHistory()
    {
        $user = Session::get('user'); // Get logged-in user
    
        // Fetch all requests for this user
        $requests = \App\Models\Request::where('user_id', $user->id)->get();
    
        return view('request.history', compact('requests'));
    }

    public function manageRequests()
    {
        // Only fetch requests that need approval
        $requests = \App\Models\Request::where('status', 'pending')->get();

        return view('request.manage', compact('requests'));
    }

    public function approveByCoordinator($id)
    {
        $request = Request::find($id);
        $request->status = 'coordinator_approved';

        // Find the Head of Office/Dean
        $head = User::where('role', 'Head of Office')->where('department', $request->department)->first();
        $request->dean_id = $head ? $head->id : null;

        $request->save();

        return redirect('/manage-requests')->with('success', 'Request approved by Coordinator.');
    }

    public function approveByDean($id)
    {
        $request = Request::find($id);
        $request->status = 'final_approved';
        $request->save();

        return redirect('/manage-requests')->with('success', 'Request fully approved.');
    }

    public function rejectRequest($id)
    {
        $request = \App\Models\Request::find($id);
        $request->status = 'rejected'; // Mark as rejected
        $request->save();

        return redirect('/manage-requests')->with('error', 'Request rejected.');
    }

    public function addComment(HttpRequest $request, $id)
    {
        // Validate input
        $request->validate([
            'comment' => 'required|string|max:255'
        ]);

        // Find the request by ID
        $requestData = \App\Models\Request::find($id);

        if (!$requestData) {
            return back()->with('error', 'Request not found');
        }

        // Save the comment
        $requestData->comments = $request->input('comment'); 
        $requestData->save();

        return redirect('/manage-requests')->with('success', 'Comment added successfully.');
    }
}
