<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard - Personnel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card p-4 w-100" style="max-width: 400px;">
            <h2 class="text-center">Personnel Dashboard</h2>

            <!-- File a Request Button -->
            <a href="/request-form" class="btn btn-primary w-100 mb-3">File as Request</a>
            
            <!-- Request History Button -->
            <a href="/request-history" class="btn btn-secondary w-100 mb-3">Request History</a>

            <!-- Logout Button (Simple Link) -->
            <a href="{{ route('logout') }}" class="btn btn-primary w-100">Logout</a>
        </div>
    </div>
</body>
</html>
