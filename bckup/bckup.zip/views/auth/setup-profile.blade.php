<!DOCTYPE html>
<html lang="en">
<head>
    <title>Profile Setup</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4">
        <h2 class="text-center">Personal Information Setup</h2>

        <form action="/setup-profile" method="POST">
            @csrf
            <div class="mb-3">
                <label>First Name</label>
                <input type="text" name="first_name" class="form-control" value="{{ old('first_name', $user->first_name ?? '') }}" required>
            </div>
            <div class="mb-3">
                <label>Last Name</label>
                <input type="text" name="last_name" class="form-control" value="{{ old('last_name', $user->last_name ?? '') }}" required>
            </div>
            <div class="mb-3">
                <label>Role</label>
                <select name="role" class="form-control" required>
                    <option value="Personnel" {{ old('role', $user->role ?? '') == 'Personnel' ? 'selected' : '' }}>Personnel</option>
                    <option value="Non-teaching personnel" {{ old('role', $user->role ?? '') == 'Non-teaching personnel' ? 'selected' : '' }}>Non-teaching personnel</option>
                    <option value="Admin" {{ old('role', $user->role ?? '') == 'Admin' ? 'selected' : '' }}>Admin</option>
                    <option value="Head of Office" {{ old('role', $user->role ?? '') == 'Head of Office' ? 'selected' : '' }}>Head of Office</option>
                    <option value="Subject Coordinator" {{ old('role', $user->role ?? '') == 'Subject Coordinator' ? 'selected' : '' }}>Subject Coordinator</option>
                </select>
            </div>
            <div class="mb-3">
                <label>Department</label>
                <select name="department" class="form-control" required>
                    @foreach($departments as $key => $department)
                        <option value="{{ $key }}" {{ old('department', $user->department ?? '') == $key ? 'selected' : '' }}>{{ $department }}</option>
                    @endforeach
                </select>
            </div>
            <div class="mb-3">
                <label>Handled Subjects</label>
                <select name="handled_subjects[]" class="form-control" multiple required>
                    <!-- Populate with subjects based on department -->
                    @foreach($subjects as $subject)
                        <option value="{{ $subject->name }}" {{ in_array($subject->name, old('handled_subjects', json_decode($user->handled_subjects ?? '[]'))) ? 'selected' : '' }}>{{ $subject->name }}</option>
                    @endforeach
                </select>
            </div>
            <button type="submit" class="btn btn-primary w-100">Save Profile</button>
        </form>
    </div>
</body>
</html>
