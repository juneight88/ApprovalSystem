<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4">
        <h2 class="text-center">Welcome, {{ $user->first_name }} {{ $user->last_name }}</h2>
        <p>Your Role: {{ $user->role }}</p>
        <p>Your Department: {{ $user->department }}</p>

        @if($user->role == 'Personnel' || $user->role == 'Non-teaching personnel')
            <a href="/file-request" class="btn btn-primary">File a Request</a>
            <a href="/request-history" class="btn btn-secondary">Request History</a>
        @elseif($user->role == 'Head of Office' || $user->role == 'Subject Coordinator')
            <a href="/file-request" class="btn btn-primary">File a Request</a>
            <a href="/request-history" class="btn btn-secondary">Request History</a>
            <a href="/manage-requests" class="btn btn-info">Manage Requests</a>
        @elseif($user->role == 'Admin')
            <a href="/view-requests" class="btn btn-primary">View Submitted Requests</a>
            <a href="/request-log-history" class="btn btn-secondary">Request Log History</a>
        @elseif($user->role == 'Super Admin')
            <a href="/manage-accounts" class="btn btn-primary">Manage Accounts</a>
            <a href="/request-log-history" class="btn btn-secondary">Request Log History</a>
        @endif
    </div>
</body>
</html>
