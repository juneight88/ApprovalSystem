<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RequestController;
use Illuminate\Support\Facades\Route;

// Redirect root URL to /login
Route::get('/', function () {
    return redirect('/login');
});

// Authentication Routes
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

// Profile Setup Routes
Route::get('/setup-profile', [UserController::class, 'setupProfile'])->middleware('authCheck');
Route::post('/setup-profile', [UserController::class, 'saveProfile'])->middleware('authCheck');

// Dashboard Route
Route::get('/dashboard', [UserController::class, 'dashboard'])->middleware('authCheck');

// Request Form Routes
Route::get('/request-form', [RequestController::class, 'showRequestForm'])->middleware('authCheck');
Route::post('/submit-request', [RequestController::class, 'submitRequest'])->middleware('authCheck');
Route::get('/request-history', [RequestController::class, 'requestHistory'])->middleware('authCheck');

Route::get('/manage-requests', [RequestController::class, 'manageRequests'])->middleware('authCheck');
Route::get('/approve-request/{id}', [RequestController::class, 'approveRequest'])->middleware('authCheck');
Route::get('/reject-request/{id}', [RequestController::class, 'rejectRequest'])->middleware('authCheck');

Route::post('/add-comment/{id}', [RequestController::class, 'addComment'])->middleware('authCheck');

